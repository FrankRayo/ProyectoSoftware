# Proyecto Grupo 5
# Diseño de Software

## Integrantes:
## Felipe Fesser - Jorge Romero - Manuel Vergara

Proyecto: **Clone Wars Adventures Emulator Website**

En este proyecto se trabajara con el objetivo de crear un sitio web utilizable para el proyecto fan-made CWAEmu

Este sitio posee la opcion de ingresar con su cuenta, rellenar un formulario para que se le proporcione una cuenta, descargar el archivo del juego, informarse de las nuevas actualizaciones, etc.
